// main page 
// header slider
$(function () {
  // Owl Carousel
  var owl = $("#horse_slider");
  owl.owlCarousel({
    items: 1,
    margin: 10,
    loop: true,
    dots: false
  });
});

// header smoot 
$(window).scroll(
  function () {
    s = $(window).scrollTop();
    if (s > 120) {
      $('.mega_menu').css({
        'position': "fixed",
        'top': '0px',
        'z-index': 9999,
      }
      )
    }
    else {
      $('.mega_menu').css({
        'position': "relative"
      }
      )
    }
  }
);

//  products 
$(function () {
  // Owl Carousel
  var owl = $("#product_slider");
  owl.owlCarousel({
    // items: 4,
    margin: 10,
    loop: true,
    nav: true, 
    autoplay: true,
    autoplayTimeout: 2000,
    responsive: {
      0: {
        items: 2,
        nav: true
      },
      600: {
        items: 3,
        nav: false
      },
      1000: {
        items: 4,
        nav: true,
        loop: true,
        dots: true
      }
    }
  });
});

$(function () {
  // Owl Carousel
  var owl = $(".owl-demo-2");
  owl.owlCarousel({
    // items: 1,
    margin: 10,
    loop: true,
    nav: true,
    autoplay:true,
    autoplayTimeout:2000,
    responsive: {
      0: {
        items: 1,
        nav: true
      },
      600: {
        items: 3,
        nav: false
      },
      1000: {
        items: 4,
        nav: true,
        loop: true,
        dots: true
      }
    }
  });
});

// spcial_offer
$(function () {
  // Owl Carousel
  var owl = $("#spcial_offer");
  owl.owlCarousel({
    // items: 1,
    margin: 10,
    loop: true,
    nav: false,
    dots: false,
    autoplay: true,
    autoplayTimeout: 2000,
    responsive: {
      0: {
        items: 2,
        nav: false
      },
      600: {
        items: 3,
        nav: false
      },
      1000: {
        items: 4,
        nav: false,
        loop: true,
        dots: false
      }
    }
  });
});


// women