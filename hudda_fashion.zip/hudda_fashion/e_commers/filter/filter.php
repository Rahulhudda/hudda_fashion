    <!-- filter start -->
    <div class="col-lg-3 m-0 p-0">
        <div class="me-2 filter">
            <!-- categories filter start -->
            <button class="women_product_filter">
                <span class="san_sarif"> CATEGORIES </span>
                <div class="women_product_border">
                    <div></div>
                </div>
            </button>
            <div class="women_product_filter_list categories ">
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Women </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Sarees </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Bridal Sarees </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Lehenga Sarees </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Partywear Sarees </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Wedding Sarees </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Bollywood Sarees </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Lehenga Choli </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Bridal Lehenga Choli </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Designer Lehenga Choli </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Bollywood Lehenga Choli </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Salwar Kameez </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Anarkali Suits </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Churidar Suits </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Designer Suits </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Gowns </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14"> <i class="fa-solid fa-angle-right me-lg-2"></i> Kurtis </li>
                    <div class="women_product_border m-0"></div>
                </a>

            </div>
            <!-- categories filter end -->

            <!-- filter price start  -->
            <button class="women_product_filter">
                <span class="san_sarif"> FILTER BY PRICE </span>
                <div class="women_product_border">
                    <div></div>
                </div>
            </button>
            <div class="women_product_filter_list san_sarif ">
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="radio"> <span class="san_sarif ms-2"> $ 0 to $ 100 </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="radio"> <span class="san_sarif ms-2"> $ 100 to $ 200 </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="radio"> <span class="san_sarif ms-2"> $ 200 to $ 300 </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="radio"> <span class="san_sarif ms-2"> $ 300 to $ 400 </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="radio"> <span class="san_sarif ms-2"> $ 400 to $ 500 </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="radio"> <span class="san_sarif ms-2"> $ 500 to $ 600 </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
            </div>
            <!-- filter price end  -->

            <!-- color filter start  -->
            <button class="women_product_filter">
                <span class="san_sarif"> COLOR </span>
                <div class="women_product_border">
                    <div></div>
                </div>
            </button>
            <div class="women_product_filter_list san_sarif ">
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg1"></span>
                            <span class="filter_color"> Aqua </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg2"></span>
                            <span class="filter_color"> Beige </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg3"></span>
                            <span class="filter_color"> Black </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg4"></span>
                            <span class="filter_color"> Blue </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg5"></span>
                            <span class="filter_color"> BlueViolet </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg6"></span>
                            <span class="filter_color"> Brown </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg7"></span>
                            <span class="filter_color"> Burgundy </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg8"></span>
                            <span class="filter_color"> Coral </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg9"></span>
                            <span class="filter_color"> CornflowerBlue </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg10"></span>
                            <span class="filter_color"> Cream </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg11"></span>
                            <span class="filter_color"> Crimson </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg12"></span>
                            <span class="filter_color"> DarkBlue </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg13"></span>
                            <span class="filter_color"> DarkGreen </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg14"></span>
                            <span class="filter_color"> DeepPink </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg15"></span>
                            <span class="filter_color"> ForestGreen </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg16"></span>
                            <span class="filter_color"> Fuchsia </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg17"></span>
                            <span class="filter_color"> Gold </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg18"></span>
                            <span class="filter_color"> Gray </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg19"></span>
                            <span class="filter_color"> Green </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg20"></span>
                            <span class="filter_color"> HotPink </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg21"></span>
                            <span class="filter_color"> Ivory </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg22"></span>
                            <span class="filter_color"> Light Brown </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg23"></span>
                            <span class="filter_color"> LightBlue </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg24"></span>
                            <span class="filter_color"> LightGray </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg25"></span>
                            <span class="filter_color"> LightGreen </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg26"></span>
                            <span class="filter_color"> LightPink </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg27"></span>
                            <span class="filter_color"> LightYellow </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg28"></span>
                            <span class="filter_color"> LimeGreen </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg29"></span>
                            <span class="filter_color"> Magenta </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg30"></span>
                            <span class="filter_color"> Maroon </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg31"></span>
                            <span class="filter_color"> MidnightBlue </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg32"></span>
                            <span class="filter_color"> Multicolor </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>

                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="circle filter_bg33"></span>
                            <span class="filter_color"> Mustard </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
            </div>
            <!-- color filter end  -->

            <!-- fabric filter start  -->
            <button class="women_product_filter">
                <span class="san_sarif"> FABRIC </span>
                <div class="women_product_border">
                    <div></div>
                </div>
            </button>
            <div class="women_product_filter_list san_sarif ">
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Art Silk </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Banarasi </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Bhagalpuri Silk </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Brasso Georgette </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Brocade </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Cotton </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Crepe </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Crepe Silk </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Dual tone silk </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Faux Chiffon </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Faux Georgette </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Imported </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Jacquard </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Jacquard Silk </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Lycra </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Net </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Pure Georgette </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Pure Silk </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Raw Silk </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Satin </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Satin Georgette </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Satin silk </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
            </div>
            <!-- fabric filter end  -->

            <!-- occasion filter start  -->
            <button class="women_product_filter">
                <span class="san_sarif"> OCCASION </span>
                <div class="women_product_border">
                    <div></div>
                </div>
            </button>
            <div class="women_product_filter_list san_sarif ">
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Casual </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Engagement </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Festival </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Mehendi </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Party Wear </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Reception </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Sangeet </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Valentine's Day </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span> Wedding </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
            </div>
            <!-- occasion filter end  -->

            <!-- dicsount filter start  -->
            <button class="women_product_filter">
                <span class="san_sarif"> DISCOUNT </span>
                <div class="women_product_border">
                    <div></div>
                </div>
            </button>
            <div class="women_product_filter_list san_sarif ">
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="san_sarif"> 0 - 10% </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="san_sarif"> 10 - 20% </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
                <a href="#">
                    <li class=" women_product_filter_list_li mid_dark-14 ">
                        <input type="checkbox">
                        <span class="san_sarif ms-4 ">
                            <span class="san_sarif"> 20 - 30% </span>
                        </span>
                    </li>
                    <div class="women_product_border m-0"></div>
                </a>
            </div>
            <!-- dicsount filter end  -->
        </div>
    </div>
    <!-- Fliter end -->