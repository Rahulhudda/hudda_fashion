-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 04, 2023 at 01:00 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hudda_fashion`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `admin_id` int(11) NOT NULL,
  `a_name` varchar(500) NOT NULL,
  `a_email` text NOT NULL,
  `a_mobile` varchar(300) NOT NULL,
  `a_password` varchar(500) NOT NULL,
  `a_code` varchar(500) NOT NULL,
  `a_address` text NOT NULL,
  `a_image` text NOT NULL,
  `a_gender` enum('Male','Female','Other') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`admin_id`, `a_name`, `a_email`, `a_mobile`, `a_password`, `a_code`, `a_address`, `a_image`, `a_gender`) VALUES
(1, 'Rahul Hudda', 'rahulhudda5167@gmail.com', '7878068656', 'hudda', '   Mom_Dad         ', 'jodhpur', '16906002911090510893favicon.jpg', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `heading_change`
--

CREATE TABLE `heading_change` (
  `id` int(11) NOT NULL,
  `m_heading` varchar(500) NOT NULL,
  `w_heading` varchar(500) NOT NULL,
  `k_heading` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `heading_change`
--

INSERT INTO `heading_change` (`id`, `m_heading`, `w_heading`, `k_heading`) VALUES
(1, ' Hudda Fashion > Men', ' Hudda Fashion >Women', ' Hudda Fashion > Kids');

-- --------------------------------------------------------

--
-- Table structure for table `kids_detail`
--

CREATE TABLE `kids_detail` (
  `id` int(11) NOT NULL,
  `k_name` varchar(500) NOT NULL,
  `k_price` varchar(500) NOT NULL,
  `k_rating` varchar(500) NOT NULL,
  `k_invoice` varchar(500) NOT NULL,
  `k_image` text NOT NULL,
  `k_status` tinyint(1) NOT NULL DEFAULT 1,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kids_detail`
--

INSERT INTO `kids_detail` (`id`, `k_name`, `k_price`, `k_rating`, `k_invoice`, `k_image`, `k_status`, `create_at`, `updated_at`) VALUES
(1, 'Wedding koti & Chola Pyjama', '2100.00', '5.0', 'INV_K-1', '16904233191752951610jodhpuri shuit.jpeg', 1, '2023-07-24 20:22:32', '2023-07-24 20:22:32'),
(2, 'Wedding Three pic', '1990.00', '4.9', 'INV_K-2', '1690339876817297103threepic.jpg', 1, '2023-07-26 02:51:16', '2023-07-26 02:51:16'),
(3, 'Western Shoot', '1100.00', '5.8', 'INV_K-3', '16903399081957075591western.jpg', 1, '2023-07-26 02:51:48', '2023-07-26 02:51:48'),
(4, 'Fancy-panda', '2200.00', '6.6', 'INV_K-4', '1690339935160663762BRANDONN.jpg', 1, '2023-07-26 02:52:15', '2023-07-26 02:52:15'),
(5, 'Fancy-Tiger', '2200.0', '6.6', 'INV_K-5', '16903401541603866151FancyDressWale.jpg', 1, '2023-07-26 02:52:19', '2023-07-26 02:52:19'),
(6, 'Fancy-laped', '2200.00', '7.7', 'INV_K-6', '1690340179341195352fansy.jpg', 1, '2023-07-26 02:52:20', '2023-07-26 02:52:20'),
(7, 'Two pic', '1282.00', '3.8', 'INV_K-7', '16903402151887607899twopics.jpg', 1, '2023-07-26 02:56:55', '2023-07-26 02:56:55'),
(8, 'Sawter', '1400.00', '4.4', 'INV_K-8', '16903402481046708704NammaBaby.jpg', 1, '2023-07-26 02:57:28', '2023-07-26 02:57:28'),
(9, 'Kafery', '1660.00', '5.0', 'INV_K-9', '16903402771311719275Hopscotch.jpg', 1, '2023-07-26 02:57:57', '2023-07-26 02:57:57'),
(10, 'Dinner Frak', '1229.00', '4.0', 'INV_K-10', '169034031462082318full_frak.jpg', 1, '2023-07-26 02:58:34', '2023-07-26 02:58:34'),
(11, 'Half-frak', '1440.00', '3.3', 'INV_K-11', '1690340353479943942half-frak.jpg', 1, '2023-07-26 02:59:13', '2023-07-26 02:59:13'),
(12, 'Skrt', '1170.00', '2.2', 'INV_K-12', '16903403891836851727fark.jpg', 1, '2023-07-26 02:59:49', '2023-07-26 02:59:49'),
(13, 'Baby kit', '1159.00', '4.3', 'INV_K-13', '16903404501067118239baby-nest.jpg', 1, '2023-07-26 03:00:50', '2023-07-26 03:00:50'),
(14, 'Baby Cap', '1099.00', '4.5', 'INV_K-14', '1690340479592978892winter_cap.jpg', 1, '2023-07-26 03:01:19', '2023-07-26 03:01:19'),
(15, 'Baby Winter Pack', '1199.00', '4.4', 'INV_K-15', '16903405131235156553WEGMANS.jpg', 1, '2023-07-26 03:01:53', '2023-07-26 03:01:53'),
(16, 'Fancy_tady', '2200.00', '8.8', 'INV_K-15', '16905112361914311011fansydress.jpg', 1, '2023-07-28 02:27:16', '2023-07-28 02:27:16'),
(17, 't_sirt', '1000', '8.8', 'INV_K-17', '1690828781886584138baby wish.jpg', 1, '2023-07-29 16:22:58', '2023-07-29 16:22:58');

-- --------------------------------------------------------

--
-- Table structure for table `man_detail`
--

CREATE TABLE `man_detail` (
  `id` int(11) NOT NULL,
  `m_name` varchar(500) NOT NULL,
  `m_price` varchar(500) NOT NULL,
  `m_rating` varchar(200) NOT NULL,
  `m_invoice` varchar(500) NOT NULL,
  `m_image` text NOT NULL,
  `m_status` tinyint(1) NOT NULL DEFAULT 1,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `man_detail`
--

INSERT INTO `man_detail` (`id`, `m_name`, `m_price`, `m_rating`, `m_invoice`, `m_image`, `m_status`, `create_at`, `updated_at`) VALUES
(1, 'Double Breasted Beige 2-Piece Suits', '1999.00', '4', 'INV_M-1', '16903290151524967313MSU305.jpg', 1, '2023-07-24 20:19:58', '2023-07-24 20:19:58'),
(2, 'Peak Lapels Slim Fit Olive Green Tuxedo', '1990.00', '4', 'INV_M-2', '16902323501049940758MSU304.jpg', 1, '2023-07-24 20:53:41', '2023-07-24 20:53:41'),
(3, 'Streetstyle Double-breasted Olive Suits', '2070.00', '4', 'INV_M-3', '16902353322092891002MSU303.jpg', 1, '2023-07-24 21:48:52', '2023-07-24 21:48:52'),
(4, 'Kurta payjama', '1200.00', '4', 'INV_M-4', '16904166101069269973kurta-payjama.jpg', 1, '2023-07-24 21:53:20', '2023-07-24 21:53:20'),
(5, 'Dinner Grey Slim Fit Suits For Men', '2900.00', '4', 'INV_M-5', '16902362361197190193MSU302.jpg', 1, '2023-07-24 21:55:49', '2023-07-24 21:55:49'),
(6, 'Men Elegant 2 Pieces Suit', '800.00', '4', 'INV_M-6', '1690236254522596525MSU301.jpg', 1, '2023-07-24 21:55:58', '2023-07-24 21:55:58'),
(7, 'Trendy Formal Mens Vest', '8000.00', '4', 'INV_M-7', '16902362661671885046MJ138.jpg', 1, '2023-07-24 21:57:14', '2023-07-24 21:57:14'),
(8, 'Summer Linen Retro Gurkha Shorts', '6000.00', '4', 'INV_M-8', '1690236389847826857SB19.jpeg', 1, '2023-07-24 21:57:26', '2023-07-24 21:57:26'),
(9, 'High Waist Gurkha Blue Hawaiian Shorts', '6200.00', '3', 'INV_M-9', '16902362951189864155SB18.jpeg', 1, '2023-07-24 21:57:35', '2023-07-24 21:57:35'),
(10, 'Military Khaki Jodhpur Riding Breeches', '6800.00', '4', 'INV_M-10', '1690236307338304939MT181.jpg', 1, '2023-07-24 21:57:44', '2023-07-24 21:57:44'),
(11, 'Valvate kot', '5000.00', '4', 'INV_M-11', '16904173222128081795MB164 (1).jpg', 1, '2023-07-25 21:11:19', '2023-07-25 21:11:19'),
(12, 'Hunter Paint', '5080.00', '4', 'INV_M-12', '16903208801158476224MT180 (1).jpg', 1, '2023-07-25 21:34:40', '2023-07-25 21:34:40'),
(13, 'Khaki High-rise Gurkha Trouser', '5800.00', '5', 'INV_M-13', '1690320927244302094MT183.jpg', 1, '2023-07-25 21:35:27', '2023-07-25 21:35:27'),
(14, 'rahul', '2000', '5', '', '16907547241059104532', 0, '2023-07-30 22:05:24', '2023-07-30 22:05:24');

-- --------------------------------------------------------

--
-- Table structure for table `user_detail`
--

CREATE TABLE `user_detail` (
  `id` int(11) NOT NULL,
  `u_name` varchar(250) NOT NULL,
  `u_email` text NOT NULL,
  `u_mobile` varchar(30) NOT NULL,
  `u_gender` enum('Male','Female','Other') NOT NULL,
  `u_password` varchar(300) NOT NULL,
  `country` varchar(250) NOT NULL,
  `states` varchar(250) NOT NULL,
  `city` varchar(250) NOT NULL,
  `u_address` text NOT NULL,
  `u_image` text NOT NULL,
  `u_status` tinyint(1) NOT NULL DEFAULT 1,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_detail`
--

INSERT INTO `user_detail` (`id`, `u_name`, `u_email`, `u_mobile`, `u_gender`, `u_password`, `country`, `states`, `city`, `u_address`, `u_image`, `u_status`, `create_at`, `updated_at`) VALUES
(1, 'Rahul hudda', 'rahulhudda5167@gmail.com', '7878068656', 'Male', 'hudda', '', 'Rajsthan', '   Jodhpur   ', 'jodhpur', '16910015471172681037rahul.jpeg', 1, '2023-07-29 00:08:36', '2023-07-29 00:08:36'),
(2, 'shyam chaudhary', 'shyam@gmail.com', '9261346812', 'Male', '5126', 'India', '', '  ', 'jodhpur', '16910015801120408689logo1.png', 1, '2023-08-01 03:08:50', '2023-08-01 03:08:50');

-- --------------------------------------------------------

--
-- Table structure for table `women_detail`
--

CREATE TABLE `women_detail` (
  `id` int(11) NOT NULL,
  `w_name` varchar(500) NOT NULL,
  `w_price` varchar(500) NOT NULL,
  `w_rating` varchar(500) NOT NULL,
  `w_invoice` varchar(500) NOT NULL,
  `w_image` text NOT NULL,
  `w_status` tinyint(1) NOT NULL DEFAULT 1,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `women_detail`
--

INSERT INTO `women_detail` (`id`, `w_name`, `w_price`, `w_rating`, `w_invoice`, `w_image`, `w_status`, `create_at`, `updated_at`) VALUES
(1, 'Pink Lycra Ready to wear sare', '1200.00', '5.0', 'INV_W-1', '16903408551983871188SM21306.jpg', 1, '2023-07-26 03:07:35', '2023-07-26 03:07:35'),
(2, 'Blue Lycra Ready to wear saree', '3000.00', '6.6', 'INV_W-2', '16903409541730343130SM21511.jpg', 1, '2023-07-26 03:08:05', '2023-07-26 03:08:05'),
(3, 'Gray Lycra Ready to wear saree', '1579.00', '4.3', 'INV_W-3', '16903411521300501719SM21518.jpg', 1, '2023-07-26 03:10:27', '2023-07-26 03:10:27'),
(4, 'Clasic Black Lycra Ready to wear saree', '1879.00', '4.5', 'INV_W-4', '16903410841137240449SM21516.jpg', 1, '2023-07-26 03:11:24', '2023-07-26 03:11:24'),
(5, 'Navy Blue Lycra Ready to wear saree', '1977.00', '4.1', 'INV_W-5', '16903411321195564393SM21513.jpg', 1, '2023-07-26 03:12:12', '2023-07-26 03:12:12'),
(6, 'Pink Lycra Ready to wear saree', '2280.00', '4.2', 'INV_W-6', '1690341429953394337SM21512.jpg', 1, '2023-07-26 03:13:28', '2023-07-26 03:13:28'),
(7, 'BlackLycra Ready to wear saree', '2582.00', '4.4', 'INV_W-7', '16903412371910917033SM21514.jpg', 1, '2023-07-26 03:13:57', '2023-07-26 03:13:57'),
(8, 'Light Green Lycra Ready to wear saree', '1577.00', '4.4', 'INV_W-8', '16903412781235711189SM21507.jpg', 1, '2023-07-26 03:14:38', '2023-07-26 03:14:38'),
(9, 'Dark Green Lycra Ready to wear saree', '1880.00', '3.8', 'INV_W-9', '169034131484099497SM21510.jpg', 1, '2023-07-26 03:15:14', '2023-07-26 03:15:14'),
(10, 'Navy Rad Lycra Ready to wear saree', '1980.00', '4.8', 'INV_W-10', '16903413671111452321SM21508.jpg', 1, '2023-07-26 03:16:07', '2023-07-26 03:16:07'),
(11, 'Green  Lycra Ready To Wear Saree', '1682.00', '4.5', 'INV_W-11', '16903414922066056053SM21509.jpg', 1, '2023-07-26 03:18:12', '2023-07-26 03:18:12'),
(12, 'Salwar', '17100.00', '2.2', 'INV_W-12', '16903416471090287831salwar-kameez.jpg', 1, '2023-07-26 03:20:47', '2023-07-26 03:20:47'),
(13, 'Rad lerya', '1200.00', '4.5', 'INV_W-13', '16903417201962262044bridallehnga.jpg', 1, '2023-07-26 03:22:00', '2023-07-26 03:22:00'),
(14, 'Lahnga Shuit', '2500.00', '4.4', 'INV_W-14', '1690341797217005369bridalsaree.jpg', 1, '2023-07-26 03:23:17', '2023-07-26 03:23:17'),
(15, 'Cyan Gagra ', '1800.00', '5.5', 'INV_W-15', '1690341839440571356lehnga-choli.jpg', 1, '2023-07-26 03:23:59', '2023-07-26 03:23:59'),
(16, 'Black sari', '2200.00', '6.6', 'INV_W-16', '16905120151700620012SM21516.jpg', 1, '2023-07-28 02:40:15', '2023-07-28 02:40:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `heading_change`
--
ALTER TABLE `heading_change`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kids_detail`
--
ALTER TABLE `kids_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `man_detail`
--
ALTER TABLE `man_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_detail`
--
ALTER TABLE `user_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `women_detail`
--
ALTER TABLE `women_detail`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `heading_change`
--
ALTER TABLE `heading_change`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `kids_detail`
--
ALTER TABLE `kids_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `man_detail`
--
ALTER TABLE `man_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `user_detail`
--
ALTER TABLE `user_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `women_detail`
--
ALTER TABLE `women_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
